export default function ownerWindow(node: Node, fallback?: Window): Window;
