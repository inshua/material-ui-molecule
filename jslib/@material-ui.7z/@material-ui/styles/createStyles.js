export default function createStyles(s) {
  return s;
}