export { default } from './Divider';
export * from './Divider';
