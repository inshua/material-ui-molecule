export function ariaHidden(show: boolean, node: Node): never;
export function hideSiblings(container: Element, mountNode: Node): never;
export function showSiblings(container: Element, mountNode: Node): never;
